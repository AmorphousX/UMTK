# pragma once

#include <Arduino.h>
#include "PCB_PinMap.h"
void setPins();
